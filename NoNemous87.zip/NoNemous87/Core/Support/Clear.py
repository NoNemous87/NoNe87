# ORIGINAL CREATOR: NoNe
# AUTHOR: NoNe
# Copyright (C) 2026 nonemous87@gmail.com>
# License: GNU General Public License v3.0

import os

Windows = "nt"


class Screen:

    def Clear():
        os.system("cls" if os.name == Windows else "clear")
