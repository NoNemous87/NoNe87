# ORIGINAL CREATOR: NoNe
# AUTHOR: NoNe
# Copyright (C) 2026 nonemous87@gmail.com>
# License: GNU General Public License v3.0

from configparser import ConfigParser

class Check:

    @staticmethod 
    def WhoIs():
        api = "Configuration/Configuration.ini"
        Parser = ConfigParser()
        Parser.read(api)
        Key = Parser["Settings"]["Api_Key"]
        return Key