# ORIGINAL CREATOR: NoNe
# AUTHOR: NoNe
# Copyright (C) 2026 nonemous87@gmail.com>
# License: GNU General Public License v3.0

class Color:
    YELLOW2 = "\033[33m"
    YELLOW = "\033[0;93m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    BLUE = "\033[94m"
    WHITE = "\033[97m"
    BANNER = "\033[41m"
    RESET = "\033[0m"
