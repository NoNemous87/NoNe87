::ORIGINAL CREATOR: NoNe
::AUTHOR: NoNe
::Copyright (C) 2026 nonemous87@gmail.com>
::License: GNU General Public License v3.0

@ECHO OFF

START /B pip3 install -r requirements.txt  2>NUL >NUL
echo INSTALLING REQUIREMENTS DO NOT CLOSE THIS WINDOW MANUALLY...
cd ../
echo path= %CD% >>NoNemous87/Configuration/Configuration.ini
echo Desktop>NoNemous87/Display/Display.txt