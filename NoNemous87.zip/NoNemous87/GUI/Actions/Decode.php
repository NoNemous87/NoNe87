<?php
    /*ORIGINAL CREATOR: NoNe
    AUTHOR: NoNe
    Copyright (C) 2026 nonemous87@gmail.com>
    License: GNU General Public License v3.0*/ 

    function Decode($content){
        $converted = base64_decode($content);
        $String = utf8_encode($converted);
        return $String;
    }
?>