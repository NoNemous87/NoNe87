<?php
    /*ORIGINAL CREATOR: NoNe
    AUTHOR: NoNe
    Copyright (C) 2026 nonemous87@gmail.com>
    License: GNU General Public License v3.0*/

    $filename = "../Maps/Temp.txt";
    $reader = fopen("../Maps/Temp.txt","r");
    $name = fgets($reader);
    fclose($reader);
    echo move_uploaded_file(
        $_FILES["upFile"]["tmp_name"],
        $name
    )? "OK":"ERROR";
?>
