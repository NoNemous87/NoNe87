/*ORIGINAL CREATOR: NoNe
AUTHOR: NoNe
Copyright (C) 2026 nonemous87@gmail.com>
License: GNU General Public License v3.0*/

function English(){
    alert("This tool has been made 🇮🇩 NoNe 🇮🇩 :)");
}

function Italiano(){
    alert("Questo tool è stato creato da 🇮🇩 NoNe🇮🇩 :)");
}

function French(){
    alert("Cette tool A été créé par 🇮🇩 NoNe 🇮🇩 :)");
}