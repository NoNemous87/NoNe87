<!--ORIGINAL CREATOR: NoNe
AUTHOR: NoNe
Copyright (C) 2026 nonemous87@gmail.com>
License: GNU General Public License v3.0-->
<!DOCTYPE html>
<html>
    <head>
        <title>Dashboard</title>
        <?php
            require_once("../Actions/Language_Controller.php");
            Total_Languages();
        ?>
        <script src = "../Script/Author.js"></script>
        <script src = "../Script/Arrow.js"></script>
        <?php
            $exception = "/firefox/i";
            $browser = $_SERVER["HTTP_USER_AGENT"];
            if(preg_match($exception,$browser)){
     
            }
            else{
                require("../Actions/Session_Checker.php");
            }
            require_once("../Actions/Theme_Controller.php");
            $File_Name = "Main.css";
            Body_Theme($File_Name);
        ?>
        <link rel = "icon" href = "../Icon/Base/Logo.png">
        <meta charset ="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=0.9">
        <meta name="theme-color" content="#000000">
    </head>
    <?php
        require_once("../Actions/Language_Controller.php");
        $Modality = "Main";
        Get_Language($Modality);
    ?>
    <div class = "Top-bar">
        <p>NoNemous87</p>
        <div class = "Hidden-bar">
            <button id = "Menu" onclick="Active_Mobile()">MENU</button>
            <div class="Options" id ="Options1">
                <a href="Username.php"></a>
                <a href="Websites.php"></a>
                <a href="Phone.php"></a>
                <a href = "Ports.php"></a>
                <a href="Email.php"></a>
                <a href="New_User.php"></a>
                <a href= "People.php"></a>
                <a id = "change1"></a>
                <?php 
                    require_once("../Actions/Language_Controller.php");
                    $Modality = "_Main_Mobile()";
                    List_Languages($Modality);
                ?>
            </div>
        </div>
        <div class = "languages">
            <button id = "Current" onclick="Active_Language()"></button>
            <div class = "Content" id = "Content">
                <?php 
                    require_once("../Actions/Language_Controller.php");
                    $Modality = "_Main()";
                    List_Languages($Modality);
                ?>
            </div>
        </div>
    </div>
    <?php require_once("../Actions/Javascript_Controller.php");NoScript_Alert();?>
    <div class = "Upper-card">
        <?php require_once("../Actions/Theme_Controller.php");Image()?>
        <p id = "Const">A COMPLETE OSINT TOOL</p>
        <div class = "Cards">
            <div id = "Username">
                <?php require_once("../Actions/Theme_Controller.php");Cards()?>
            </div>
        </div>
        <a href = "#Footer" id = "Arrow" onclick="Active()"></a>
        <div class = "Footer" id = "Footer" name = "Footer">
            <p id = "Const">MY-CONTACTS</p>
            <div class = "Board">
                <a href = "https://www.instagram.com/nonemous87?igsh=MXZ4dWM1Z3VqNjV5Nw==" target = "blank"><img src = "../Icon/instagram.png" id = "Exc" abbr title = "Instagram"></a>
                <a href = "nonemous87@gmail.com" target = "blank"><img src = "../Icon/Email.png" abbr title = "Email" ></a>
            </div>
        </div>
    </body>
</html>
